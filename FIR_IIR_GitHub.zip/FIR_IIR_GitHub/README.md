# Bộ lọc số FIR / IIR

Ứng dụng desktop tiếng Việt để mô phỏng và so sánh bộ lọc thông thấp **FIR Hamming** và **IIR Butterworth**.

![Giao diện ứng dụng](FIR_IIR_Giao_dien.png)

## Tải và sử dụng trên Windows

1. Mở mục **Releases** của repository này.
2. Trong **Assets**, tải **FIR_IIR_Windows.zip** ở phiên bản mới nhất.
3. Giải nén toàn bộ tệp ZIP.
4. Mở thư mục `FIR_IIR_App`, nhấp đúp `FIR_IIR_App.exe`.

Bản dùng sẵn không yêu cầu cài Python. Giữ nguyên các tệp và thư mục bên cạnh EXE.

Nếu chưa có `FIR_IIR_Windows.zip` trong Releases thì bản dùng sẵn chưa được phát hành. `Source code (zip)` là mã nguồn, cần Python để chạy.

## Chức năng

- Tạo tín hiệu sin, thêm nhiễu sin hoặc ngẫu nhiên; nhập dãy mẫu/CSV/TXT.
- Chọn FIR, IIR hoặc so sánh cả hai; điều chỉnh thông số thiết kế.
- Một đồ thị lớn, có bảng chọn đồ thị và bật/tắt từng đường.
- Phát tín hiệu theo chỉ số mẫu n: tạm dừng, tua, tiến một mẫu, chỉnh tốc độ.
- Xem phổ, đáp ứng biên độ, pha, xung, bậc thang và bảng mẫu.
- Xuất toàn bộ kết quả CSV; lưu đồ thị PNG, SVG hoặc PDF.

Đồ thị động phát lại dữ liệu mô phỏng. Tốc độ phát độc lập với tần số lấy mẫu. Ứng dụng hiện hỗ trợ **thông thấp**; không thu âm/tín hiệu trực tiếp từ thiết bị.

## Chạy từ mã nguồn

Cần Python 3.10 trở lên và Tkinter.

```bash
python -m pip install -r requirements.txt
python FIR_IIR_App.py
```

Trên Windows cũng có thể chạy `CAI_DAT.bat` rồi `CHAY_UNG_DUNG.bat`. Xem [hướng dẫn đầy đủ](HUONG_DAN.md).

## Tạo bản phát hành

Trên Windows, mở `TAO_BAN_WINDOWS.bat`. Script cài thư viện đóng gói vào `.venv-build`, rồi tạo:

```text
dist/FIR_IIR_Windows.zip
```

Giải nén, thử chạy ứng dụng, sau đó đính kèm ZIP trong GitHub Releases. Xem [hướng dẫn đăng GitHub](DANG_LEN_GITHUB.md).
