"""Phòng mô phỏng bộ lọc số FIR / IIR — giao diện tiếng Việt.

Python 3.10+. Cài đặt: py -m pip install numpy scipy matplotlib
Chạy: py FIR_IIR_App.py

Mô phỏng thông thấp, điều kiện đầu bằng 0, lọc nhân quả một lượt.
Đồ thị phát lại kết quả theo chỉ số mẫu; tốc độ phát độc lập với fs.
"""
from __future__ import annotations

import csv
import io
import math
import re
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy import signal

MAX_SAMPLES = 20_000
COLORS = {"input": "#8291A7", "clean": "#845AC7", "FIR": "#087F8C", "IIR": "#DC8132"}
NAMES = {"input": "Đầu vào x[n]", "clean": "Tín hiệu gốc", "FIR": "Đầu ra FIR", "IIR": "Đầu ra IIR"}
VIEWS = {
    "signal": "Tín hiệu theo mẫu",
    "spectrum": "Phổ tín hiệu",
    "gain": "Đáp ứng biên độ",
    "phase": "Đáp ứng pha",
    "impulse": "Đáp ứng xung",
    "step": "Đáp ứng bậc thang",
    "table": "Bảng giá trị mẫu",
}


def finite_number(value, label: str) -> float:
    try:
        number = float(str(value).strip().replace(",", "."))
    except (ValueError, TypeError) as exc:
        raise ValueError(f"{label}: vui lòng nhập một số.") from exc
    if not math.isfinite(number):
        raise ValueError(f"{label}: giá trị phải là số hữu hạn.")
    return number


def integer_value(value, label: str, low: int, high: int) -> int:
    number = finite_number(value, label)
    if not number.is_integer() or not low <= number <= high:
        raise ValueError(f"{label}: nhập số nguyên từ {low} đến {high}.")
    return int(number)


def validate_fs_cutoff(fs: float, cutoff: float) -> None:
    if not math.isfinite(fs) or fs <= 0:
        raise ValueError("Tần số lấy mẫu phải lớn hơn 0.")
    if not math.isfinite(cutoff) or not 0 < cutoff < fs / 2:
        raise ValueError(f"Tần số cắt phải lớn hơn 0 và nhỏ hơn {fs / 2:g} Hz (một nửa tần số lấy mẫu).")


def validate_samples(x) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if x.ndim != 1 or not 4 <= x.size <= MAX_SAMPLES or not np.all(np.isfinite(x)):
        raise ValueError("Dãy tín hiệu cần từ 4 đến 20.000 mẫu hữu hạn.")
    # Keep FFTs and power calculations in a useful numerical range.
    if np.max(np.abs(x)) > 1e12:
        raise ValueError("Biên độ mẫu quá lớn. Hãy chuẩn hóa dữ liệu về khoảng ±10¹² hoặc nhỏ hơn.")
    return x


def design_fir_lowpass(fs: float, cutoff: float, num_taps: int):
    validate_fs_cutoff(fs, cutoff)
    num_taps = integer_value(num_taps, "Số hệ số FIR", 3, 1001)
    if num_taps % 2 == 0:
        raise ValueError("Số hệ số FIR phải là số lẻ, ví dụ 31, 51 hoặc 101.")
    return signal.firwin(num_taps, cutoff, window="hamming", fs=fs), np.array([1.0])


def design_iir_lowpass(fs: float, cutoff: float, order: int):
    """Giữ API hệ số b, a của bản cũ; ứng dụng tính IIR bằng SOS."""
    validate_fs_cutoff(fs, cutoff)
    order = integer_value(order, "Bậc IIR", 1, 12)
    return signal.butter(order, cutoff, btype="lowpass", fs=fs)


def solve_difference_equation(b, a, x) -> np.ndarray:
    """a[0]y[n] = Σ b[k]x[n-k] − Σ(k>=1) a[k]y[n-k]."""
    b, a, x = (np.asarray(v, dtype=float) for v in (b, a, x))
    if any(v.ndim != 1 or not np.all(np.isfinite(v)) for v in (b, a, x)):
        raise ValueError("Hệ số và tín hiệu phải là các dãy số hữu hạn một chiều.")
    if b.size == 0 or a.size == 0 or a[0] == 0:
        raise ValueError("Hệ số bộ lọc không hợp lệ; a[0] phải khác 0.")
    return signal.lfilter(b, a, x)


def impulse_response(b, a, length: int = 120) -> np.ndarray:
    length = integer_value(length, "Độ dài đáp ứng xung", 1, MAX_SAMPLES)
    impulse = np.zeros(length)
    impulse[0] = 1.0
    return solve_difference_equation(b, a, impulse)


def frequency_response(b, a, fs: float, points: int = 4096):
    return signal.freqz(b, a, worN=points, fs=fs)


def magnitude_spectrum(x, fs: float):
    """Phổ biên độ một phía; Hann, hiệu chỉnh biên độ DC và Nyquist."""
    x = validate_samples(x)
    if not math.isfinite(fs) or fs <= 0:
        raise ValueError("Tần số lấy mẫu phải lớn hơn 0.")
    window = np.hanning(x.size)
    magnitude = 2 * np.abs(np.fft.rfft(x * window)) / np.sum(window)
    magnitude[0] *= 0.5
    if x.size % 2 == 0:
        magnitude[-1] *= 0.5
    return np.fft.rfftfreq(x.size, 1 / fs), magnitude


def attenuation_at(b, a, fs: float, frequency_hz: float) -> float:
    _, h = signal.freqz(b, a, worN=np.array([frequency_hz]), fs=fs)
    return float(20 * np.log10(max(abs(h[0]), 1e-12)))


def create_sample_signal(fs, sample_count, signal_hz, signal_amplitude,
                         noise_mode, noise_hz, noise_amplitude, seed=None):
    fs = finite_number(fs, "Tần số lấy mẫu")
    if fs <= 0:
        raise ValueError("Tần số lấy mẫu phải lớn hơn 0.")
    count = integer_value(sample_count, "Số mẫu", 4, MAX_SAMPLES)
    signal_hz = finite_number(signal_hz, "Tần số tín hiệu")
    if not 0 <= signal_hz < fs / 2:
        raise ValueError(f"Tần số tín hiệu phải từ 0 đến dưới {fs / 2:g} Hz.")
    if noise_mode not in ("none", "sin", "white"):
        raise ValueError("Kiểu nhiễu không hợp lệ.")
    signal_amplitude = finite_number(signal_amplitude, "Biên độ tín hiệu")
    noise_amplitude = finite_number(noise_amplitude, "Mức nhiễu") if noise_mode != "none" else 0
    if not 0 <= signal_amplitude <= 1e10 or not 0 <= noise_amplitude <= 1e10:
        raise ValueError("Biên độ tín hiệu và mức nhiễu phải nằm trong khoảng 0 đến 10¹⁰.")
    n = np.arange(count)
    clean = signal_amplitude * np.sin(2 * np.pi * (signal_hz / fs) * n)
    if noise_mode == "sin":
        noise_hz = finite_number(noise_hz, "Tần số nhiễu")
        if not 0 <= noise_hz < fs / 2:
            raise ValueError(f"Tần số nhiễu phải từ 0 đến dưới {fs / 2:g} Hz.")
        noise = noise_amplitude * np.sin(2 * np.pi * (noise_hz / fs) * n)
    elif noise_mode == "white":
        noise = noise_amplitude * np.random.default_rng(seed).standard_normal(count)
    else:
        noise = np.zeros(count)
    return n / fs, clean, clean + noise


def create_custom_signal(fs, duration, signal_hz, signal_amplitude,
                         noise_mode, noise_hz, noise_amplitude, seed=None):
    """Hàm tương thích bản cũ; giao diện mới nhập trực tiếp số mẫu."""
    duration = finite_number(duration, "Thời lượng")
    fs = finite_number(fs, "Tần số lấy mẫu")
    if duration <= 0 or fs <= 0 or not math.isfinite(duration * fs):
        raise ValueError("Thời lượng và tần số lấy mẫu phải dương, hữu hạn.")
    return create_sample_signal(fs, round(duration * fs), signal_hz,
                                signal_amplitude, noise_mode, noise_hz, noise_amplitude, seed)


def parse_sample_values(text: str) -> np.ndarray:
    try:
        values = [float(p) for p in re.split(r"[\s,;]+", text.strip()) if p]
    except ValueError as exc:
        raise ValueError("Dãy mẫu chỉ chứa số. Dùng dấu chấm thập phân; phân cách bằng dấu phẩy, chấm phẩy hoặc xuống dòng.") from exc
    return validate_samples(values)


def read_sample_file(path) -> np.ndarray:
    """Không gộp nhầm cột thời gian vào tín hiệu khi nhập CSV nhiều cột."""
    raw = Path(path).read_text(encoding="utf-8-sig").strip()
    if not raw:
        raise ValueError("Tệp dữ liệu đang trống.")
    first = raw.splitlines()[0]
    delimiter = ";" if ";" in first else "\t" if "\t" in first else ","
    rows = [r for r in csv.reader(io.StringIO(raw), delimiter=delimiter) if any(c.strip() for c in r)]
    header = [c.strip().lower() for c in rows[0]]
    aliases = ("input_x", "x[n]", "x", "value", "amplitude", "sample", "dau_vao", "đầu vào")
    match = next((header.index(c) for c in aliases if c in header), None)
    if match is not None:
        try:
            return validate_samples([float(r[match]) for r in rows[1:]])
        except (ValueError, IndexError) as exc:
            raise ValueError("Cột tín hiệu có ô trống, thiếu ô hoặc giá trị không hợp lệ.") from exc
    if len(rows) > 1 and any(len(r) > 1 for r in rows):
        raise ValueError("CSV nhiều cột cần tên cột tín hiệu là input_x hoặc x[n]. Với dãy mẫu thuần, dùng tệp một cột hoặc một hàng.")
    return parse_sample_values(raw)


@dataclass
class FilterResult:
    name: str
    b: np.ndarray
    a: np.ndarray
    y: np.ndarray
    sos: np.ndarray | None = None

    def apply(self, x):
        return signal.sosfilt(self.sos, x) if self.sos is not None else signal.lfilter(self.b, self.a, x)

    def response(self, fs, points=2048):
        if self.sos is not None:
            # sosfreqz remains available in older SciPy used on Windows.
            return signal.sosfreqz(self.sos, worN=points, fs=fs)
        return signal.freqz(self.b, self.a, worN=points, fs=fs)

    def gain_at(self, fs, hz):
        _, h = self.response(fs, np.array([float(hz)]))
        return float(20 * np.log10(max(abs(h[0]), 1e-12)))


def simulate_filters(x, fs, cutoff, taps, order, choice) -> dict[str, FilterResult]:
    x = validate_samples(x)
    validate_fs_cutoff(fs, cutoff)
    if choice not in ("fir", "iir", "both"):
        raise ValueError("Chọn FIR, IIR hoặc cả hai bộ lọc.")
    results = {}
    if choice in ("fir", "both"):
        b, a = design_fir_lowpass(fs, cutoff, taps)
        results["FIR"] = FilterResult("FIR", b, a, signal.lfilter(b, a, x))
    if choice in ("iir", "both"):
        order = integer_value(order, "Bậc IIR", 1, 12)
        sos = signal.butter(order, cutoff, btype="lowpass", fs=fs, output="sos")
        b, a = signal.sos2tf(sos)
        b, a = np.trim_zeros(b, "b"), np.trim_zeros(a, "b")
        results["IIR"] = FilterResult("IIR", b, a, signal.sosfilt(sos, x), sos)
    if any(not np.all(np.isfinite(result.y)) for result in results.values()):
        raise ValueError("Bộ thông số này gây lỗi tính toán. Hãy kiểm tra lại biên độ và tần số.")
    return results


def simulate_user_input(x, fs, cutoff, taps, order, choice):
    """Giữ dạng trả về (b, a, y) của phiên bản cũ."""
    return {k: (v.b, v.a, v.y) for k, v in simulate_filters(x, fs, cutoff, taps, order, choice).items()}


@dataclass
class Simulation:
    fs: float
    cutoff: float
    x: np.ndarray
    clean: np.ndarray | None
    outputs: dict[str, FilterResult]
    source_hz: float | None = None
    noise_hz: float | None = None

    def series(self):
        data = {"input": self.x}
        if self.clean is not None:
            data["clean"] = self.clean
        data.update({k: v.y for k, v in self.outputs.items()})
        return data


def write_simulation_csv(path, result: Simulation) -> None:
    series = result.series()
    fields = ["n", "time_s", "input_x"]
    keys = ["input"]
    if "clean" in series:
        fields.append("clean_signal")
        keys.append("clean")
    for key in ("FIR", "IIR"):
        if key in series:
            fields.append("output_" + key.lower())
            keys.append(key)
    with open(path, "w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(fields)
        for n in range(len(result.x)):
            writer.writerow([n, format(n / result.fs, ".17g")] + [format(series[k][n], ".17g") for k in keys])


class FilterApp:
    """Tkinter + Matplotlib, không cần trình duyệt hay kết nối mạng."""
    BG = "#EEF2F7"
    INK = "#152A43"
    MUTED = "#677990"
    WHITE = "#FFFFFF"
    ACCENT = "#087F8C"

    def __init__(self, root):
        import tkinter as tk
        from tkinter import ttk
        self.tk, self.ttk, self.root = tk, ttk, root
        self.result = None
        self.playing = False
        self.after_id = None
        self.cursor = 0
        self.position = 0.0
        self.full_view = False
        self.dirty = False
        self._slider_lock = False
        self._loading = False
        self._table_page = 0
        self._cache = {}
        self._artists = {}
        self._marker_line = None
        self._tip = None
        self.sidebar_visible = True
        self.vars = {k: tk.StringVar(value=v) for k, v in {
            "fs": "1000", "count": "2000", "frequency": "50", "amplitude": "1",
            "noise_frequency": "200", "noise_amplitude": "0.65", "cutoff": "100",
            "taps": "51", "order": "4"}.items()}
        self.labels = {"fs": "Tần số lấy mẫu", "count": "Số mẫu", "frequency": "Tần số tín hiệu",
                       "amplitude": "Biên độ tín hiệu", "noise_frequency": "Tần số nhiễu",
                       "noise_amplitude": "Mức nhiễu", "cutoff": "Tần số cắt",
                       "taps": "Số hệ số FIR", "order": "Bậc IIR"}
        self.source = tk.StringVar(value="sine")
        self.noise = tk.StringVar(value="sin")
        self.choice = tk.StringVar(value="both")
        self.view = tk.StringVar(value="signal")
        self.speed = tk.StringVar(value="200")
        self.window_size = tk.StringVar(value="160")
        self.stems = tk.BooleanVar(value=False)
        self.show = {key: tk.BooleanVar(value=key != "clean") for key in NAMES}
        self.status = tk.StringVar(value="Sẵn sàng · Nhấn Chạy mô phỏng để bắt đầu.")
        self.counter = tk.StringVar(value="Chưa có dữ liệu")
        self.note = tk.StringVar(value="Tín hiệu rời rạc được biểu diễn theo chỉ số mẫu n.")
        self.badge = tk.StringVar(value="SẴN SÀNG")
        self.source_note = tk.StringVar()
        self.entries = {}
        self._setup_style()
        self._build_ui()
        self._bind_changes()
        self.update_fields()
        self.render()
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.bind("<F5>", lambda _e: self.run())
        root.bind("<F11>", lambda _e: root.attributes("-fullscreen", not root.attributes("-fullscreen")))
        root.bind("<Escape>", lambda _e: root.attributes("-fullscreen", False))

    def _setup_style(self):
        from tkinter import font as tkfont
        root = self.root
        root.title("Bộ lọc số | FIR & IIR")
        width = min(1440, root.winfo_screenwidth() - 60)
        height = min(900, root.winfo_screenheight() - 90)
        root.geometry(f"{max(1000, width)}x{max(640, height)}")
        root.minsize(1000, 640)
        root.configure(bg=self.BG)
        family = "Segoe UI" if "Segoe UI" in tkfont.families(root) else "DejaVu Sans"
        self.family = family
        for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont"):
            tkfont.nametofont(name).configure(family=family, size=10)
        style = self.ttk.Style(root)
        style.theme_use("clam")
        style.configure(".", font=(family, 10), background=self.BG, foreground=self.INK)
        style.configure("TFrame", background=self.BG)
        style.configure("Card.TFrame", background=self.WHITE)
        style.configure("TLabel", background=self.WHITE)
        style.configure("Muted.TLabel", foreground=self.MUTED, background=self.WHITE, font=(family, 9))
        style.configure("Heading.TLabel", font=(family, 11, "bold"), background=self.WHITE)
        style.configure("TButton", padding=(10, 7), background="#E6EDF4", borderwidth=0, focusthickness=1)
        style.map("TButton", background=[("active", "#D8E3EE"), ("disabled", "#EDF1F5")], foreground=[("disabled", "#9BA9B8")])
        style.configure("Primary.TButton", background=self.ACCENT, foreground=self.WHITE, font=(family, 10, "bold"), padding=(16, 10))
        style.map("Primary.TButton", background=[("active", "#096C77"), ("disabled", "#99C7CC")], foreground=[("disabled", "#EFF7F8")])
        style.configure("TEntry", padding=6, fieldbackground="#F6F8FC", bordercolor="#DCE4EE")
        style.configure("TCombobox", padding=5, fieldbackground="#F6F8FC")
        style.map("TCombobox", fieldbackground=[("readonly", "#F6F8FC")])
        style.configure("TRadiobutton", background=self.WHITE, padding=(0, 4))
        style.configure("TCheckbutton", background=self.WHITE, padding=(0, 4))
        style.configure("TNotebook", background=self.WHITE, borderwidth=0, tabmargins=0)
        style.configure("TNotebook.Tab", padding=(11, 9), background="#E8EEF5")
        style.map("TNotebook.Tab", background=[("selected", self.WHITE)], foreground=[("selected", self.ACCENT)])
        style.configure("Treeview", background=self.WHITE, fieldbackground=self.WHITE, rowheight=29, borderwidth=0)
        style.configure("Treeview.Heading", background="#E7EEF5", foreground=self.INK, font=(family, 10, "bold"), padding=7)
        style.configure("Horizontal.TScale", background=self.WHITE, troughcolor="#DFE9F1")

    def _build_ui(self):
        tk, ttk = self.tk, self.ttk
        self.root.rowconfigure(1, weight=1)
        self.root.columnconfigure(0, weight=1)
        header = tk.Frame(self.root, bg=self.INK, padx=20, pady=14)
        header.grid(row=0, column=0, sticky="ew")
        brand = tk.Frame(header, bg=self.INK)
        brand.pack(side="left")
        tk.Label(brand, text="BỘ LỌC SỐ", font=(self.family, 20, "bold"), bg=self.INK, fg="white").pack(anchor="w")
        tk.Label(brand, text="FIR / IIR  ·  PHÒNG MÔ PHỎNG", font=(self.family, 9), bg=self.INK, fg="#A9C3D4").pack(anchor="w")
        self.run_button = ttk.Button(header, text="▶  Chạy mô phỏng", style="Primary.TButton", command=self.run)
        self.run_button.pack(side="right", padx=(12, 0))
        self.csv_button = ttk.Button(header, text="Xuất CSV", command=self.save_csv, state="disabled")
        self.csv_button.pack(side="right", padx=(6, 0))
        self.image_button = ttk.Button(header, text="Lưu hình", command=self.save_plot, state="disabled")
        self.image_button.pack(side="right", padx=(6, 0))
        self.panel_button = ttk.Button(header, text="Ẩn thiết lập", command=self.toggle_sidebar)
        self.panel_button.pack(side="right", padx=(6, 0))
        body = ttk.Frame(self.root, padding=(14, 14, 14, 8))
        body.grid(row=1, column=0, sticky="nsew")
        body.rowconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        self.sidebar = ttk.Frame(body, style="Card.TFrame", width=300)
        self.sidebar.grid(row=0, column=0, sticky="ns", padx=(0, 12))
        self.sidebar.grid_propagate(False)
        self.sidebar.rowconfigure(1, weight=1)
        self.sidebar.columnconfigure(0, weight=1)
        ttk.Label(self.sidebar, text="THIẾT LẬP MÔ PHỎNG", style="Heading.TLabel", padding=(15, 16, 10, 12)).grid(row=0, column=0, sticky="w")
        self.settings_tabs = ttk.Notebook(self.sidebar)
        self.settings_tabs.grid(row=1, column=0, sticky="nsew")
        self.source_tab = self._scroll_tab("Tín hiệu")
        self.filter_tab = self._scroll_tab("Bộ lọc")
        self.display_tab = self._scroll_tab("Đồ thị")
        self._build_source(self.source_tab)
        self._build_filter(self.filter_tab)
        self._build_display(self.display_tab)
        ttk.Button(self.sidebar, text="Hướng dẫn sử dụng", command=self.help).grid(row=2, column=0, sticky="ew", padx=12, pady=12)

        self.workspace = ttk.Frame(body, style="Card.TFrame", padding=(16, 14, 16, 12))
        self.workspace.grid(row=0, column=1, sticky="nsew")
        self.workspace.rowconfigure(2, weight=1)
        self.workspace.columnconfigure(0, weight=1)
        top = ttk.Frame(self.workspace, style="Card.TFrame")
        top.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        self.view_title = ttk.Label(top, text=VIEWS["signal"], font=(self.family, 17, "bold"))
        self.view_title.pack(side="left")
        tk.Label(top, textvariable=self.badge, bg="#E6F4F1", fg="#147F76", padx=10, pady=5, font=(self.family, 9, "bold")).pack(side="right")
        switch = ttk.Frame(self.workspace, style="Card.TFrame")
        switch.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(switch, text="Đang xem", style="Muted.TLabel").pack(side="left", padx=(0, 8))
        self.view_combo = ttk.Combobox(switch, values=list(VIEWS.values()), state="readonly", width=24)
        self.view_combo.set(VIEWS["signal"])
        self.view_combo.bind("<<ComboboxSelected>>", self._select_combo)
        self.view_combo.pack(side="left")
        ttk.Button(switch, text="Chọn đường vẽ", command=self.open_display).pack(side="left", padx=8)
        self.metric = ttk.Label(switch, text="", style="Muted.TLabel")
        self.metric.pack(side="right")
        self.plot_frame = ttk.Frame(self.workspace, style="Card.TFrame")
        self.plot_frame.grid(row=2, column=0, sticky="nsew")
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
        from matplotlib.figure import Figure
        self.figure = Figure(figsize=(10, 5.5), dpi=100, facecolor=self.WHITE)
        self.figure.subplots_adjust(left=.085, right=.975, top=.91, bottom=.145)
        self.ax = self.figure.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.figure, master=self.plot_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        self.canvas.mpl_connect("resize_event", self._resize_plot)
        self.nav = NavigationToolbar2Tk(self.canvas, self.plot_frame, pack_toolbar=False)
        self.canvas.mpl_connect("motion_notify_event", self.hover)
        self.table_frame = ttk.Frame(self.workspace, style="Card.TFrame")
        self.table_frame.rowconfigure(0, weight=1)
        self.table_frame.columnconfigure(0, weight=1)
        columns = ("n", "time", "input", "clean", "FIR", "IIR")
        self.table = ttk.Treeview(self.table_frame, columns=columns, show="headings")
        for name, label in zip(columns, ("Mẫu n", "Thời gian (s)", "Đầu vào x[n]", "Tín hiệu gốc", "Đầu ra FIR", "Đầu ra IIR")):
            self.table.heading(name, text=label)
            self.table.column(name, width=105 if name != "n" else 65, minwidth=50, anchor="e")
        self.table.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(self.table_frame, orient="vertical", command=self.table.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.table.configure(yscrollcommand=scrollbar.set)
        self.table.tag_configure("even", background="#F3F7FB")
        pages = ttk.Frame(self.table_frame, style="Card.TFrame", padding=(0, 8))
        pages.grid(row=1, column=0, columnspan=2, sticky="ew")
        self.page_prev = ttk.Button(pages, text="← Trang trước", command=lambda: self.change_page(-1))
        self.page_prev.pack(side="left")
        self.page_label = ttk.Label(pages, text="", style="Muted.TLabel")
        self.page_label.pack(side="left", padx=10)
        self.page_next = ttk.Button(pages, text="Trang sau →", command=lambda: self.change_page(1))
        self.page_next.pack(side="left")
        self._build_playback()
        footer = tk.Frame(self.root, bg=self.BG, padx=18, pady=6)
        footer.grid(row=2, column=0, sticky="ew")
        self.status_label = tk.Label(footer, textvariable=self.status, bg=self.BG, fg=self.MUTED, anchor="w", font=(self.family, 9))
        self.status_label.pack(side="left", fill="x", expand=True)
        tk.Label(footer, text="F5  Chạy   ·   F11  Toàn màn hình", bg=self.BG, fg=self.MUTED, font=(self.family, 9)).pack(side="right")

    def _scroll_tab(self, title):
        tk, ttk = self.tk, self.ttk
        wrapper = ttk.Frame(self.settings_tabs, style="Card.TFrame")
        self.settings_tabs.add(wrapper, text=title)
        canvas = tk.Canvas(wrapper, bg=self.WHITE, highlightthickness=0, width=276)
        scroll = ttk.Scrollbar(wrapper, orient="vertical", command=canvas.yview)
        scroll.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        canvas.configure(yscrollcommand=scroll.set)
        inner = ttk.Frame(canvas, style="Card.TFrame", padding=14)
        item = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(item, width=e.width))
        def wheel(event):
            if inner.winfo_reqheight() > canvas.winfo_height():
                units = -int(event.delta / 120) if event.delta else (-1 if event.num == 4 else 1)
                canvas.yview_scroll(units, "units")
                return "break"
        # Unique bind tag only for the tab descendants, not the whole app.
        tag = f"SidebarWheel{id(inner)}"
        self.root.bind_class(tag, "<MouseWheel>", wheel)
        self.root.bind_class(tag, "<Button-4>", wheel)
        self.root.bind_class(tag, "<Button-5>", wheel)
        def bind_descendants():
            def visit(widget):
                if widget.winfo_class() not in ("Text", "TCombobox"):
                    widget.bindtags((tag,) + widget.bindtags())
                for child in widget.winfo_children():
                    visit(child)
            visit(inner)
            canvas.bindtags((tag,) + canvas.bindtags())
        self.root.after_idle(bind_descendants)
        inner.wrapper = wrapper
        return inner

    def _section(self, parent, text, note=None):
        self.ttk.Label(parent, text=text, style="Heading.TLabel").pack(anchor="w", pady=(12, 4))
        if note:
            self.ttk.Label(parent, text=note, style="Muted.TLabel", wraplength=247, justify="left").pack(anchor="w", pady=(0, 7))

    def _field(self, parent, label, key):
        frame = self.ttk.Frame(parent, style="Card.TFrame")
        frame.pack(fill="x", pady=5)
        self.ttk.Label(frame, text=label, font=(self.family, 9)).pack(anchor="w", pady=(0, 4))
        entry = self.ttk.Entry(frame, textvariable=self.vars[key])
        entry.pack(fill="x")
        self.entries[key] = entry
        return entry

    def _build_source(self, parent):
        ttk = self.ttk
        self._section(parent, "Nguồn tín hiệu")
        for label, value in (("Tạo sóng sin", "sine"), ("Nhập dãy mẫu / tệp", "samples")):
            ttk.Radiobutton(parent, text=label, variable=self.source, value=value).pack(anchor="w")
        self._field(parent, "Tần số lấy mẫu (Hz)", "fs")
        self.sine_fields = ttk.Frame(parent, style="Card.TFrame")
        self.sine_fields.pack(fill="x")
        self._field(self.sine_fields, "Số mẫu cần mô phỏng", "count")
        self._field(self.sine_fields, "Tần số tín hiệu (Hz)", "frequency")
        self._field(self.sine_fields, "Biên độ tín hiệu", "amplitude")
        self._section(self.sine_fields, "Nhiễu đầu vào")
        for label, value in (("Không thêm nhiễu", "none"), ("Nhiễu hình sin", "sin"), ("Nhiễu ngẫu nhiên", "white")):
            ttk.Radiobutton(self.sine_fields, text=label, variable=self.noise, value=value).pack(anchor="w")
        self._field(self.sine_fields, "Tần số nhiễu (Hz)", "noise_frequency")
        self._field(self.sine_fields, "Mức nhiễu", "noise_amplitude")
        self.noise_note = ttk.Label(self.sine_fields, text="", style="Muted.TLabel", wraplength=247, justify="left")
        self.noise_note.pack(anchor="w", pady=(2, 8))
        self.sample_fields = ttk.Frame(parent, style="Card.TFrame")
        self._section(self.sample_fields, "Dãy đầu vào x[n]", "Dấu chấm thập phân. Ngăn các mẫu bằng dấu phẩy, khoảng trắng hoặc xuống dòng.")
        self.sample_text = self.tk.Text(self.sample_fields, height=9, width=22, wrap="word", relief="flat", bg="#F3F6FA", fg=self.INK, padx=8, pady=8, font=(self.family, 10), undo=True)
        self.sample_text.pack(fill="x")
        self.sample_text.insert("1.0", "0, 1, 0.5, -0.5, -1, 0, 0.5, 1")
        self.sample_text.edit_modified(False)
        ttk.Button(self.sample_fields, text="Mở tệp CSV / TXT", command=self.import_samples).pack(fill="x", pady=10)
        ttk.Label(self.sample_fields, text="Một cột biên độ, hoặc CSV có cột input_x / x[n].", style="Muted.TLabel", wraplength=247).pack(anchor="w")
        self.source_hint = ttk.Label(parent, textvariable=self.source_note, style="Muted.TLabel", wraplength=247, justify="left")
        self.source_hint.pack(anchor="w", pady=10)

    def _build_filter(self, parent):
        ttk = self.ttk
        self._section(parent, "Bộ lọc thông thấp", "Giữ thành phần tần số thấp và làm suy giảm thành phần tần số cao.")
        for label, value in (("So sánh FIR và IIR", "both"), ("Chỉ sử dụng FIR", "fir"), ("Chỉ sử dụng IIR", "iir")):
            ttk.Radiobutton(parent, text=label, variable=self.choice, value=value).pack(anchor="w")
        self._field(parent, "Tần số cắt (Hz)", "cutoff")
        self._section(parent, "FIR · Cửa sổ Hamming")
        self._field(parent, "Số hệ số FIR (số lẻ)", "taps")
        ttk.Label(parent, text="Bậc FIR = số hệ số − 1.\nTrễ nhóm = (số hệ số − 1) / 2 mẫu.", style="Muted.TLabel", wraplength=247).pack(anchor="w", pady=4)
        self._section(parent, "IIR · Butterworth")
        self._field(parent, "Bậc IIR (1–12)", "order")
        ttk.Label(parent, text="Lọc nhân quả một lượt, có giữ trễ và quá độ ban đầu.", style="Muted.TLabel", wraplength=247).pack(anchor="w", pady=4)
        self._section(parent, "Khi so sánh", "Tần số cắt FIR ở gần mức −6 dB; IIR Butterworth ở −3 dB. Hai bộ lọc không có cùng quy ước tại điểm cắt.")
        self.info_button = ttk.Button(parent, text="Thông số và hệ số bộ lọc", command=self.show_filter_info, state="disabled")
        self.info_button.pack(fill="x", pady=12)

    def _build_display(self, parent):
        ttk = self.ttk
        self._section(parent, "Chọn đồ thị", "Mỗi lần xem một đồ thị lớn.")
        for key, label in VIEWS.items():
            ttk.Radiobutton(parent, text=label, variable=self.view, value=key, command=self.change_view).pack(anchor="w")
        self._section(parent, "Đường cần hiển thị")
        self.series_checks = {}
        for key, label in NAMES.items():
            row = ttk.Frame(parent, style="Card.TFrame")
            row.pack(fill="x")
            self.tk.Label(row, text="●", fg=COLORS[key], bg=self.WHITE).pack(side="left", padx=(0, 4))
            cb = ttk.Checkbutton(row, text=label, variable=self.show[key], command=self.render)
            cb.pack(side="left")
            self.series_checks[key] = cb
        self._section(parent, "Cửa sổ quan sát")
        ttk.Label(parent, text="Số mẫu trên khung hình", style="Muted.TLabel").pack(anchor="w")
        combo = ttk.Combobox(parent, textvariable=self.window_size, values=("80", "160", "320", "640", "1000"), state="readonly")
        combo.pack(fill="x", pady=6)
        combo.bind("<<ComboboxSelected>>", self.change_window)
        ttk.Checkbutton(parent, text="Vẽ cọc mẫu rời rạc", variable=self.stems, command=self.render).pack(anchor="w", pady=4)
        ttk.Label(parent, text="Chấm biểu diễn mẫu thật; đường nối hỗ trợ quan sát. Tốc độ phát không thay đổi tần số lấy mẫu.", style="Muted.TLabel", wraplength=247, justify="left").pack(anchor="w", pady=7)

    def _build_playback(self):
        ttk = self.ttk
        self.plot_tools = ttk.Frame(self.workspace, style="Card.TFrame")
        self.plot_tools.grid(row=3, column=0, sticky="ew", pady=(2, 6))
        ttk.Button(self.plot_tools, text="Vừa khung", command=self.fit_plot).pack(side="left")
        self.zoom_button = ttk.Button(self.plot_tools, text="Phóng vùng", command=lambda: self.navigation("zoom"))
        self.zoom_button.pack(side="left", padx=5)
        self.pan_button = ttk.Button(self.plot_tools, text="Kéo đồ thị", command=lambda: self.navigation("pan"))
        self.pan_button.pack(side="left")
        self.hover_label = ttk.Label(self.plot_tools, text="", style="Muted.TLabel")
        self.hover_label.pack(side="right")
        self.note_label = ttk.Label(self.workspace, textvariable=self.note, style="Muted.TLabel", wraplength=830, justify="left")
        self.note_label.grid(row=4, column=0, sticky="ew", pady=(2, 8))
        self.workspace.bind("<Configure>", self._workspace_resize)
        self.playback = ttk.Frame(self.workspace, style="Card.TFrame")
        self.playback.grid(row=5, column=0, sticky="ew")
        self.playback.columnconfigure(0, weight=1)
        controls = ttk.Frame(self.playback, style="Card.TFrame")
        controls.grid(row=0, column=0, sticky="ew")
        self.play_button = ttk.Button(controls, text="▶  Phát", command=self.toggle_play, style="Primary.TButton", state="disabled")
        self.play_button.pack(side="left")
        self.reset_button = ttk.Button(controls, text="Về đầu", command=self.restart, state="disabled", width=0)
        self.reset_button.pack(side="left", padx=5)
        self.step_button = ttk.Button(controls, text="+1 mẫu", command=self.step_one, state="disabled", width=0)
        self.step_button.pack(side="left")
        self.all_button = ttk.Button(controls, text="Xem toàn bộ", command=self.show_all, state="disabled", width=0)
        self.all_button.pack(side="left", padx=5)
        ttk.Label(controls, text="mẫu/s", style="Muted.TLabel").pack(side="right", padx=(5, 0))
        self.speed_combo = ttk.Combobox(controls, textvariable=self.speed, values=("25", "50", "100", "200", "500", "1000", "2000"), state="readonly", width=6)
        self.speed_combo.pack(side="right")
        self.speed_combo.bind("<<ComboboxSelected>>", lambda _e: self._reset_clock())
        self.speed_caption = ttk.Label(controls, text="Tốc độ phát", style="Muted.TLabel")
        self.speed_caption.pack(side="right", padx=8)
        progress = ttk.Frame(self.playback, style="Card.TFrame")
        progress.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        self.slider = ttk.Scale(progress, from_=0, to=1, command=self.scrub, state="disabled")
        self.slider.pack(side="left", fill="x", expand=True)
        ttk.Label(progress, textvariable=self.counter, style="Muted.TLabel", width=30, anchor="e").pack(side="right", padx=(12, 0))

    def _resize_plot(self, event):
        width, height = max(event.width, 1), max(event.height, 1)
        self.figure.subplots_adjust(left=min(.18, max(.075, 66 / width)),
                                    right=.975, bottom=min(.34, max(.12, 56 / height)),
                                    top=1 - min(.24, max(.08, 34 / height)))

    def _workspace_resize(self, event):
        self.note_label.configure(wraplength=max(400, event.width - 40))
        if hasattr(self, "speed_caption"):
            if event.width < 780:
                self.speed_caption.pack_forget()
            elif not self.speed_caption.winfo_manager():
                self.speed_caption.pack(side="right", padx=8)

    def _bind_changes(self):
        for variable in (*self.vars.values(), self.source, self.noise, self.choice):
            variable.trace_add("write", self._parameter_changed)
        self.sample_text.bind("<<Modified>>", self._sample_changed)

    def _parameter_changed(self, *_):
        self.update_fields()
        if self.result is not None and not self._loading:
            self.pause()
            self.dirty = True
            self.badge.set("CẦN CHẠY LẠI")
            self.status.set("Thông số đã đổi · Đồ thị là kết quả lần trước. Nhấn Chạy mô phỏng để cập nhật.")
            self._enable_result_controls(False)

    def _sample_changed(self, _event=None):
        if self.sample_text.edit_modified():
            self.sample_text.edit_modified(False)
            if self.source.get() == "samples":
                self._parameter_changed()

    def update_fields(self):
        sine = self.source.get() == "sine"
        if sine:
            self.sample_fields.pack_forget()
            self.sine_fields.pack(fill="x", before=self.source_hint)
        else:
            self.sine_fields.pack_forget()
            self.sample_fields.pack(fill="x", before=self.source_hint)
        for key in ("count", "frequency", "amplitude"):
            self.entries[key].configure(state="normal" if sine else "disabled")
        self.entries["noise_frequency"].configure(state="normal" if sine and self.noise.get() == "sin" else "disabled")
        self.entries["noise_amplitude"].configure(state="normal" if sine and self.noise.get() != "none" else "disabled")
        self.entries["taps"].configure(state="normal" if self.choice.get() != "iir" else "disabled")
        self.entries["order"].configure(state="normal" if self.choice.get() != "fir" else "disabled")
        self.noise_note.configure(text="Mức nhiễu là độ lệch chuẩn. Mỗi lần chạy tạo một dãy nhiễu mới." if self.noise.get() == "white" else "Mức nhiễu là biên độ sóng sin." if self.noise.get() == "sin" else "Đầu vào chính là tín hiệu gốc.")
        try:
            fs = finite_number(self.vars["fs"].get(), "Tần số lấy mẫu")
            count = integer_value(self.vars["count"].get(), "Số mẫu", 4, MAX_SAMPLES)
            if fs <= 0:
                raise ValueError
            self.source_note.set(f"{count:,} mẫu ≈ {count / fs:g} s · Giới hạn tần số: dưới {fs / 2:g} Hz." if sine else f"Tần số dữ liệu nhập phải phù hợp với tần số lấy mẫu {fs:g} Hz.")
        except ValueError:
            self.source_note.set("Nhập thông số rồi nhấn Chạy mô phỏng.")

    def number(self, key):
        return finite_number(self.vars[key].get(), self.labels[key])

    def run(self):
        from tkinter import messagebox
        self.pause()
        try:
            fs, cutoff = self.number("fs"), self.number("cutoff")
            validate_fs_cutoff(fs, cutoff)
            clean = None
            source_hz = noise_hz = None
            if self.source.get() == "samples":
                x = parse_sample_values(self.sample_text.get("1.0", "end"))
            else:
                source_hz = self.number("frequency")
                noise_hz = self.number("noise_frequency") if self.noise.get() == "sin" else None
                _, clean, x = create_sample_signal(fs, self.vars["count"].get(), source_hz, self.number("amplitude"), self.noise.get(), noise_hz or 0, self.number("noise_amplitude") if self.noise.get() != "none" else 0)
            outputs = simulate_filters(x, fs, cutoff,
                                       self.vars["taps"].get() if self.choice.get() != "iir" else 3,
                                       self.vars["order"].get() if self.choice.get() != "fir" else 1,
                                       self.choice.get())
            self.result = Simulation(fs, cutoff, x.copy(), clean, outputs, source_hz, noise_hz)
            self.dirty = False
            self.cursor, self.position, self.full_view = 0, 0.0, False
            self._cache.clear()
            self._table_page = 0
            self._enable_result_controls(True)
            self._slider_lock = True
            self.slider.configure(to=len(x) - 1)
            self.slider.set(0)
            self._slider_lock = False
            self.metric.configure(text=f"{len(x):,} mẫu  ·  {fs:g} Hz")
            self.status.set(f"Đã tính {len(x):,} mẫu · Thông thấp {cutoff:g} Hz · " + " + ".join(outputs))
            for name, box in self.series_checks.items():
                box.configure(state="normal" if name in self.result.series() else "disabled")
            if not any(self.show[k].get() for k in self.result.series()):
                for key in outputs:
                    self.show[key].set(True)
            self.render()
            self._update_counter()
            self.badge.set("ĐÃ TÍNH XONG")
            if self.view.get() == "signal":
                self.start_play()
        except (ValueError, OverflowError, FloatingPointError) as exc:
            messagebox.showerror("Kiểm tra thông số", str(exc), parent=self.root)

    def _enable_result_controls(self, enabled):
        state = "normal" if enabled else "disabled"
        for widget in (self.csv_button, self.info_button, self.play_button, self.reset_button, self.step_button, self.all_button, self.slider):
            widget.configure(state=state)
        self.image_button.configure(state=state if self.view.get() != "table" else "disabled")

    def toggle_sidebar(self):
        if self.sidebar_visible:
            self.sidebar.grid_remove()
        else:
            self.sidebar.grid()
        self.sidebar_visible = not self.sidebar_visible
        self.panel_button.configure(text="Ẩn thiết lập" if self.sidebar_visible else "Hiện thiết lập")

    def open_display(self):
        if not self.sidebar_visible:
            self.toggle_sidebar()
        self.settings_tabs.select(self.display_tab.wrapper)

    def _select_combo(self, _event=None):
        self.view.set(next(k for k, v in VIEWS.items() if v == self.view_combo.get()))
        self.change_view()

    def change_view(self):
        self.pause()
        self._clear_navigation()
        self.view_combo.set(VIEWS[self.view.get()])
        self.render()

    def change_window(self, _event=None):
        self.full_view = False
        self.render()

    def selected_series(self):
        if self.result is None:
            return {}
        return {k: v for k, v in self.result.series().items() if self.show[k].get()}

    def selected_filters(self):
        return {k: v for k, v in self.result.outputs.items() if self.show[k].get()}

    def _style_axes(self):
        ax = self.ax
        ax.set_facecolor(self.WHITE)
        ax.tick_params(colors=self.MUTED, labelsize=9, length=0, pad=8)
        for name, spine in ax.spines.items():
            spine.set_visible(name in ("left", "bottom"))
            spine.set_color("#DCE5ED")
        ax.grid(True, color="#DFE7EF", alpha=.75, linewidth=.7)
        ax.set_axisbelow(True)
        ax.xaxis.label.set_color(self.MUTED)
        ax.yaxis.label.set_color(self.MUTED)
        ax.xaxis.label.set_size(10)
        ax.yaxis.label.set_size(10)

    def render(self):
        from matplotlib.ticker import MaxNLocator
        view = self.view.get()
        self.view_title.configure(text=VIEWS[view])
        self.view_combo.set(VIEWS[view])
        is_table = view == "table"
        if is_table:
            self.plot_frame.grid_remove()
            self.plot_tools.grid_remove()
            self.table_frame.grid(row=2, column=0, sticky="nsew")
            self.playback.grid_remove()
            self.note.set("Bảng chứa toàn bộ kết quả, chia 500 mẫu/trang. CSV xuất đủ dữ liệu với chỉ số n.")
            self.fill_table()
        else:
            self.table_frame.grid_remove()
            self.plot_frame.grid(row=2, column=0, sticky="nsew")
            self.plot_tools.grid(row=3, column=0, sticky="ew", pady=(2, 6))
            if view == "signal":
                self.playback.grid(row=5, column=0, sticky="ew")
            else:
                self.playback.grid_remove()
            self.ax.clear()
            self._artists.clear()
            self._marker_line = self._tip = None
            self._style_axes()
            self.hover_label.configure(text="")
            if self.result is None:
                self.ax.set_axis_off()
                self.ax.text(.5, .56, "Khám phá tín hiệu sau bộ lọc", transform=self.ax.transAxes, ha="center", fontsize=20, color=self.INK, weight="bold")
                self.ax.text(.5, .44, "1. Thiết lập tín hiệu    2. Chọn bộ lọc    3. Chạy mô phỏng", transform=self.ax.transAxes, ha="center", fontsize=11, color=self.MUTED)
                self.ax.text(.5, .33, "Chọn từng đồ thị trong bảng Đồ thị để quan sát chi tiết.", transform=self.ax.transAxes, ha="center", fontsize=10, color=self.MUTED)
            else:
                self.ax.set_axis_on()
                if view == "signal":
                    self._draw_signal()
                elif view == "spectrum":
                    self._draw_spectrum()
                elif view in ("gain", "phase"):
                    self._draw_response(view)
                else:
                    self._draw_test_response(view)
                if view in ("signal", "impulse", "step"):
                    self.ax.xaxis.set_major_locator(MaxNLocator(nbins=9, integer=True))
                handles, labels = self.ax.get_legend_handles_labels()
                if handles:
                    self.ax.legend(loc="upper left", bbox_to_anchor=(0, 1.12), ncol=min(len(handles), 4), frameon=False, fontsize=9, handlelength=2)
                else:
                    self.ax.text(.5, .5, "Bật một đường vẽ trong bảng Đồ thị.", transform=self.ax.transAxes, ha="center", color=self.MUTED)
            self.nav.update()
            self.canvas.draw_idle()
        if self.result is not None:
            self.image_button.configure(state="normal" if not self.dirty and not is_table else "disabled")

    def _draw_signal(self):
        series = self.selected_series()
        self.ax.set(xlabel="Chỉ số mẫu n", ylabel="Biên độ")
        self.ax.axhline(0, color="#B6C3D1", linewidth=.8)
        for key, values in series.items():
            line, = self.ax.plot([], [], label=NAMES[key], color=COLORS[key], linewidth=1.35 if key == "input" else 1.9, alpha=.65 if key == "input" else .95, linestyle="--" if key == "clean" else "-", marker="o", markersize=3)
            stems = self.ax.vlines([], [], [], colors=COLORS[key], linewidth=.7, alpha=.45)
            self._artists[key] = (line, stems, values)
        if series:
            minimum = min(float(np.min(v)) for v in series.values())
            maximum = max(float(np.max(v)) for v in series.values())
            padding = max((maximum - minimum) * .14, 0.05)
            self.ax.set_ylim(minimum - padding, maximum + padding)
        else:
            self.ax.set_ylim(-1, 1)
        self._marker_line = self.ax.axvline(self.cursor, color="#254D70", linestyle=":", linewidth=1, alpha=.6)
        self._tip = self.ax.annotate("", xy=(0, 0), xytext=(14, 15), textcoords="offset points", bbox={"boxstyle": "round,pad=.6", "fc": "#F0F5FA", "ec": "#D7E2ED"}, color=self.INK, fontsize=9, zorder=20)
        self._tip.set_visible(False)
        self._update_signal()
        delay = f" FIR trễ {(len(self.result.outputs['FIR'].b) - 1) // 2} mẫu." if "FIR" in self.result.outputs else ""
        self.note.set("Phát kết quả theo chỉ số mẫu n; khung nhìn cuộn theo dữ liệu." + delay + " Di chuột để đọc giá trị.")

    def _update_signal(self):
        if self.result is None or self.view.get() != "signal":
            return
        stop = self.cursor + 1
        window = int(self.window_size.get())
        start = 0 if self.full_view else max(0, stop - window)
        count = stop - start
        indices = np.arange(start, stop)
        for line, stems, values in self._artists.values():
            line.set_data(indices, values[start:stop])
            line.set_marker("o" if count <= 700 else "")
            line.set_linestyle("None" if self.stems.get() and count <= 1000 else ("--" if line.get_label() == NAMES["clean"] else "-"))
            if self.stems.get() and count <= 1000:
                segments = np.empty((count, 2, 2))
                segments[:, 0, 0] = segments[:, 1, 0] = indices
                segments[:, 0, 1] = 0
                segments[:, 1, 1] = values[start:stop]
                stems.set_segments(segments)
            else:
                stems.set_segments([])
        # Manual zoom/pan remains in place while paused.
        right = len(self.result.x) - 1 if self.full_view else min(len(self.result.x) - 1, max(window - 1, self.cursor))
        self.ax.set_xlim(start - .5, max(right + .5, start + 1))
        if self._marker_line is not None:
            self._marker_line.set_xdata([self.cursor, self.cursor])
        if self._tip is not None:
            self._tip.set_visible(False)
        self.canvas.draw_idle()

    def _draw_spectrum(self):
        maximum = -120.0
        for key, data in self.selected_series().items():
            cache_key = ("spectrum", key)
            if cache_key not in self._cache:
                self._cache[cache_key] = magnitude_spectrum(data, self.result.fs)
            f, mag = self._cache[cache_key]
            db = 20 * np.log10(np.maximum(mag, 1e-12))
            maximum = max(maximum, float(np.max(db)))
            self.ax.plot(f, db, label=NAMES[key], color=COLORS[key], linewidth=1.4, alpha=.75 if key == "input" else 1)
        self.ax.set(xlabel="Tần số (Hz)", ylabel="Biên độ (dB, mốc 1)", xlim=(0, self.result.fs / 2), ylim=(max(-240, maximum - 110), max(5, maximum + 8)))
        self.note.set("Phổ của toàn bộ dãy mẫu, dùng cửa sổ Hann. Mốc 0 dB tương ứng biên độ 1; phổ không chạy theo thanh phát.")

    def _draw_response(self, view):
        for key, result in self.selected_filters().items():
            if ("response", key) not in self._cache:
                self._cache[("response", key)] = result.response(self.result.fs)
            f, h = self._cache[("response", key)]
            if view == "gain":
                values = 20 * np.log10(np.maximum(np.abs(h), 1e-12))
            else:
                values = np.unwrap(np.angle(h)) * 180 / np.pi
                # Phase at deep magnitude nulls is not a useful measurement.
                values = np.where(np.abs(h) >= 1e-5, values, np.nan)
            self.ax.plot(f, values, label=key, color=COLORS[key], linewidth=2)
        self.ax.axvline(self.result.cutoff, color="#95A6B6", linestyle="--", linewidth=1)
        self.ax.text(self.result.cutoff, .98, f"  {self.result.cutoff:g} Hz", transform=self.ax.get_xaxis_transform(), va="top", color=self.MUTED, fontsize=9)
        self.ax.set(xlabel="Tần số (Hz)", ylabel="Độ lợi (dB)" if view == "gain" else "Pha (độ)", xlim=(0, self.result.fs / 2))
        if view == "gain":
            self.ax.set_ylim(-120, 5)
        self.note.set("Đặc tính bộ lọc, độc lập với tín hiệu vào. Tại tần số cắt: FIR xấp xỉ −6 dB; IIR Butterworth −3 dB." if view == "gain" else "Pha đã tháo cuộn. Ẩn pha ở vùng độ lợi dưới −100 dB; FIR pha tuyến tính, IIR có pha phi tuyến.")

    def _draw_test_response(self, view):
        length = min(MAX_SAMPLES, max(160, len(self.result.x), max(len(r.b) for r in self.result.outputs.values()) + 32))
        longest = 0
        for key, result in self.selected_filters().items():
            cache_key = (view, key)
            if cache_key not in self._cache:
                x = np.ones(length) if view == "step" else np.zeros(length)
                x[0] = 1
                self._cache[cache_key] = result.apply(x)
            data = self._cache[cache_key]
            # A useful default window, but retain the full computed response.
            last = max(160, len(result.b) + 20)
            if view == "impulse":
                active = np.flatnonzero(np.abs(data) > max(np.max(np.abs(data)) * 1e-3, 1e-14))
            else:
                active = np.flatnonzero(np.abs(data - 1) > 1e-3)
            if active.size:
                last = max(last, int(active[-1]) + 20)
            last = min(length, last)
            longest = max(longest, last)
            n = np.arange(length)
            self.ax.plot(n, data, color=COLORS[key], label=key, linewidth=1.6, marker="o" if last < 400 else "", markersize=2.6)
            if self.stems.get() and last <= 1000:
                self.ax.vlines(n[:last], 0, data[:last], colors=COLORS[key], alpha=.35, linewidth=.7)
        self.ax.axhline(0, color="#B6C3D1", linewidth=.7)
        self.ax.set(xlabel="Chỉ số mẫu n", ylabel="h[n]" if view == "impulse" else "s[n]", xlim=(-1, max(20, longest)))
        self.note.set(f"Đầu vào kiểm tra: {'xung đơn vị δ[n]' if view == 'impulse' else 'bậc thang đơn vị u[n]'}. Tính {length:,} mẫu; đáp ứng IIR được quan sát trên một khoảng hữu hạn.")

    def _clear_navigation(self):
        mode = str(self.nav.mode)
        if mode == "zoom rect":
            self.nav.zoom()
        elif mode == "pan/zoom":
            self.nav.pan()
        self.zoom_button.configure(text="Phóng vùng")
        self.pan_button.configure(text="Kéo đồ thị")

    def navigation(self, action):
        self.pause()
        getattr(self.nav, action)()
        self.zoom_button.configure(text="Thoát phóng" if str(self.nav.mode) == "zoom rect" else "Phóng vùng")
        self.pan_button.configure(text="Thoát kéo" if str(self.nav.mode) == "pan/zoom" else "Kéo đồ thị")

    def fit_plot(self):
        self._clear_navigation()
        self.render()

    def hover(self, event):
        if self.result is None or event.inaxes != self.ax or event.xdata is None:
            if self._tip is not None and self._tip.get_visible():
                self._tip.set_visible(False)
                self.canvas.draw_idle()
            return
        if self.view.get() == "signal" and not self.playing and not str(self.nav.mode):
            n = int(round(event.xdata))
            if 0 <= n <= self.cursor and self.selected_series():
                series = self.selected_series()
                text = f"n = {n}  ·  t = {n / self.result.fs:.5g} s\n" + "\n".join(f"{NAMES[k]}: {v[n]:.6g}" for k, v in series.items())
                key = min(series, key=lambda k: abs(series[k][n] - (event.ydata or 0)))
                self._tip.xy = (n, series[key][n])
                self._tip.set_text(text)
                near_right = event.x > self.ax.bbox.x0 + self.ax.bbox.width * .65
                near_top = event.y > self.ax.bbox.y0 + self.ax.bbox.height * .55
                self._tip.set_position((-14 if near_right else 14, -15 if near_top else 15))
                self._tip.set_ha("right" if near_right else "left")
                self._tip.set_va("top" if near_top else "bottom")
                self._tip.set_visible(True)
                self.canvas.draw_idle()
        if event.ydata is not None:
            unit = "n" if self.view.get() in ("signal", "step", "impulse") else "Hz"
            self.hover_label.configure(text=f"{event.xdata:.5g} {unit}  ·  {event.ydata:.5g}")

    def _reset_clock(self):
        self.last_tick = time.perf_counter()

    def start_play(self):
        if self.result is None or self.dirty:
            return
        self._clear_navigation()
        if self.view.get() != "signal":
            self.view.set("signal")
            self.render()
        if self.cursor >= len(self.result.x) - 1:
            self.cursor, self.position = 0, 0.0
        self.full_view = False
        self.playing = True
        self.badge.set("ĐANG PHÁT")
        self.play_button.configure(text="Ⅱ  Tạm dừng")
        self._reset_clock()
        self._update_signal()
        self._update_counter()
        if self.after_id is None:
            self.after_id = self.root.after(33, self._tick)

    def pause(self):
        self.playing = False
        if self.after_id is not None:
            self.root.after_cancel(self.after_id)
            self.after_id = None
        if hasattr(self, "play_button"):
            self.play_button.configure(text="▶  Phát")
        if self.result is not None and not self.dirty:
            self.badge.set("TẠM DỪNG")

    def toggle_play(self):
        self.pause() if self.playing else self.start_play()

    def _tick(self):
        self.after_id = None
        if not self.playing or self.result is None or self.dirty:
            return
        now = time.perf_counter()
        self.position = min(len(self.result.x) - 1, self.position + (now - self.last_tick) * float(self.speed.get()))
        self.last_tick = now
        new_cursor = int(self.position)
        if new_cursor != self.cursor:
            self.cursor = new_cursor
            self._update_signal()
            self._update_counter()
        if self.cursor >= len(self.result.x) - 1:
            self.pause()
            self.badge.set("HOÀN TẤT")
        else:
            self.after_id = self.root.after(33, self._tick)

    def _update_counter(self):
        if self.result is None:
            return
        self.counter.set(f"n = {self.cursor:,}  ·  {self.cursor + 1:,} / {len(self.result.x):,} mẫu")
        self._slider_lock = True
        self.slider.set(self.cursor)
        self._slider_lock = False

    def restart(self):
        if self.result is None or self.dirty:
            return
        self.pause()
        self.cursor, self.position, self.full_view = 0, 0.0, False
        self._clear_navigation()
        self._update_signal()
        self._update_counter()

    def step_one(self):
        if self.result is None or self.dirty:
            return
        self.pause()
        self.full_view = False
        self.cursor = min(self.cursor + 1, len(self.result.x) - 1)
        self.position = float(self.cursor)
        self._clear_navigation()
        self._update_signal()
        self._update_counter()

    def show_all(self):
        if self.result is None or self.dirty:
            return
        self.pause()
        self.cursor = len(self.result.x) - 1
        self.position = float(self.cursor)
        self.full_view = True
        self._clear_navigation()
        self._update_signal()
        self._update_counter()
        self.badge.set("TOÀN BỘ MẪU")

    def scrub(self, value):
        if self._slider_lock or self.result is None or self.dirty:
            return
        self.pause()
        self.cursor = max(0, min(len(self.result.x) - 1, int(round(float(value)))))
        self.position = float(self.cursor)
        self.full_view = False
        self._clear_navigation()
        self._update_signal()
        self._update_counter()

    def fill_table(self):
        self.table.delete(*self.table.get_children())
        if self.result is None:
            self.page_label.configure(text="Chạy mô phỏng để xem dữ liệu.")
            self.page_prev.configure(state="disabled")
            self.page_next.configure(state="disabled")
            return
        count = len(self.result.x)
        pages = math.ceil(count / 500)
        self._table_page = max(0, min(self._table_page, pages - 1))
        start = self._table_page * 500
        series = self.result.series()
        for n in range(start, min(start + 500, count)):
            values = [n, f"{n / self.result.fs:.7g}"] + [f"{series[k][n]:.8g}" if k in series else "—" for k in ("input", "clean", "FIR", "IIR")]
            self.table.insert("", "end", values=values, tags=("even",) if n % 2 == 0 else ())
        self.page_label.configure(text=f"Trang {self._table_page + 1}/{pages} · {count:,} mẫu")
        self.page_prev.configure(state="normal" if self._table_page else "disabled")
        self.page_next.configure(state="normal" if self._table_page + 1 < pages else "disabled")

    def change_page(self, delta):
        self._table_page += delta
        self.fill_table()

    def import_samples(self):
        from tkinter import filedialog, messagebox
        self.pause()
        path = filedialog.askopenfilename(parent=self.root, title="Chọn dữ liệu tín hiệu", filetypes=[("Dữ liệu CSV / TXT", "*.csv *.txt"), ("Mọi tệp", "*.*")])
        if not path:
            return
        try:
            samples = read_sample_file(path)
            self.source.set("samples")
            self.sample_text.delete("1.0", "end")
            self.sample_text.insert("1.0", "\n".join(format(v, ".17g") for v in samples))
            self.sample_text.edit_modified(False)
            self._parameter_changed()
            self.status.set(f"Đã nạp {len(samples):,} mẫu · Nhấn Chạy mô phỏng.")
        except (OSError, UnicodeError, ValueError) as exc:
            messagebox.showerror("Không đọc được tệp", str(exc), parent=self.root)

    def save_csv(self):
        from tkinter import filedialog, messagebox
        if self.result is None or self.dirty:
            return
        self.pause()
        path = filedialog.asksaveasfilename(parent=self.root, title="Xuất toàn bộ mẫu", defaultextension=".csv", initialfile="Ket_qua_FIR_IIR.csv", filetypes=[("Bảng CSV", "*.csv")])
        if path:
            try:
                write_simulation_csv(path, self.result)
                self.status.set(f"Đã xuất {len(self.result.x):,} mẫu · {Path(path).name}")
            except OSError as exc:
                messagebox.showerror("Không lưu được dữ liệu", str(exc), parent=self.root)

    def save_plot(self):
        from tkinter import filedialog, messagebox
        if self.result is None or self.dirty or self.view.get() == "table":
            return
        self.pause()
        path = filedialog.asksaveasfilename(parent=self.root, title="Lưu đồ thị đang xem", defaultextension=".png", initialfile=f"Do_thi_{self.view.get()}.png", filetypes=[("Ảnh PNG", "*.png"), ("Ảnh vector SVG", "*.svg"), ("Tài liệu PDF", "*.pdf")])
        if path:
            try:
                if self._tip is not None:
                    self._tip.set_visible(False)
                original_title = self.ax.get_title()
                self.ax.set_title(f"{VIEWS[self.view.get()]} · fs = {self.result.fs:g} Hz · fc = {self.result.cutoff:g} Hz", loc="center", fontsize=11, pad=34)
                try:
                    self.figure.savefig(path, dpi=180, bbox_inches="tight", facecolor="white")
                finally:
                    self.ax.set_title(original_title)
                    self.canvas.draw_idle()
                self.status.set(f"Đã lưu đồ thị đang xem · {Path(path).name}")
            except (OSError, ValueError) as exc:
                messagebox.showerror("Không lưu được đồ thị", str(exc), parent=self.root)

    def _text_window(self, title, content):
        self.pause()
        win = self.tk.Toplevel(self.root)
        win.title(title)
        win.geometry("780x630")
        win.minsize(500, 380)
        win.configure(bg=self.WHITE)
        self.ttk.Label(win, text=title, font=(self.family, 16, "bold"), padding=16).pack(anchor="w")
        frame = self.ttk.Frame(win, style="Card.TFrame", padding=(16, 0, 16, 16))
        frame.pack(fill="both", expand=True)
        text = self.tk.Text(frame, wrap="word", relief="flat", bg="#F5F8FC", fg=self.INK, padx=16, pady=12, spacing1=4, spacing3=4, font=(self.family, 10))
        scroll = self.ttk.Scrollbar(frame, command=text.yview)
        scroll.pack(side="right", fill="y")
        text.configure(yscrollcommand=scroll.set)
        text.pack(fill="both", expand=True)
        text.insert("1.0", content)
        text.configure(state="disabled")
        return win

    def show_filter_info(self):
        if self.result is None or self.dirty:
            return
        r = self.result
        chunks = [f"THÔNG SỐ LẦN CHẠY\n{len(r.x):,} mẫu · fs = {r.fs:g} Hz · fc = {r.cutoff:g} Hz\nĐiều kiện đầu: bằng 0. Lọc nhân quả, một lượt.\n"]
        for key, result in r.outputs.items():
            chunks.append(f"{key}\nBậc: {len(result.b) - 1}\nĐộ lợi tại tần số cắt: {result.gain_at(r.fs, r.cutoff):.3f} dB")
            if key == "FIR":
                delay = (len(result.b) - 1) // 2
                chunks.append(f"Trễ nhóm: {delay} mẫu = {delay / r.fs:g} s")
            if r.source_hz is not None:
                chunks.append(f"Độ lợi tại tín hiệu {r.source_hz:g} Hz: {result.gain_at(r.fs, r.source_hz):.3f} dB")
            if r.noise_hz is not None:
                chunks.append(f"Độ lợi tại nhiễu {r.noise_hz:g} Hz: {result.gain_at(r.fs, r.noise_hz):.3f} dB")
            chunks.append("b = " + np.array2string(result.b, precision=10, separator=", ", threshold=1100, max_line_width=90))
            chunks.append("a = " + np.array2string(result.a, precision=10, separator=", ", threshold=1100, max_line_width=90))
            if result.sos is not None:
                chunks.append("IIR được tính bằng các tầng bậc hai để giảm sai số số học. Mỗi hàng: [b0, b1, b2, a0, a1, a2].\n" + np.array2string(result.sos, precision=10, separator=", ", max_line_width=90))
            chunks.append("")
        chunks.append("PHƯƠNG TRÌNH SAI PHÂN\na[0] y[n] = Σ b[k] x[n−k] − Σ (k≥1) a[k] y[n−k]\n\nTần số cắt FIR Hamming và IIR Butterworth có quy ước khác nhau: gần −6 dB và −3 dB. Không tự dịch tín hiệu để che độ trễ.")
        self._text_window("Thông số và hệ số bộ lọc", "\n\n".join(chunks))

    def help(self):
        self._text_window("Hướng dẫn sử dụng", """BẮT ĐẦU
1. Trong Tín hiệu, nhập tần số lấy mẫu, số mẫu, tần số và biên độ tín hiệu. Chọn loại nhiễu nếu cần.
2. Trong Bộ lọc, chọn FIR / IIR / cả hai; nhập tần số cắt và số hệ số hoặc bậc.
3. Nhấn Chạy mô phỏng (F5). Đồ thị tín hiệu tự phát theo thứ tự mẫu.

QUAN SÁT MẪU
Phát / Tạm dừng: điều khiển trình phát.
Về đầu: dừng ở mẫu n = 0. +1 mẫu: tiến đúng một mẫu.
Thanh trượt: tua đến chỉ số mẫu bất kỳ.
Xem toàn bộ: hiện cả dãy. Bấm Phát để chạy lại từ đầu.
Tốc độ phát (mẫu/s) chỉ thay đổi cách trình diễn; fs vẫn quyết định tín hiệu và bộ lọc. Đây là phát lại dữ liệu mô phỏng, không phải thu tín hiệu trực tiếp từ thiết bị.

CHỌN ĐỒ THỊ
Dùng danh sách Đang xem hoặc bảng Đồ thị. Bật/tắt riêng đầu vào, tín hiệu gốc và từng đầu ra. Đáp ứng biên độ, pha, xung và bậc thang chỉ dùng lựa chọn FIR/IIR.
Tín hiệu theo mẫu chạy động. Phổ và đặc tính bộ lọc được tính từ toàn bộ dữ liệu và xem tĩnh. Trục mẫu bắt đầu tại n = 0; thời gian tương ứng t = n / fs.
Di chuột khi tạm dừng để đọc giá trị. Phóng vùng: kéo chuột trái khoanh vùng. Kéo đồ thị: kéo để di chuyển. Vừa khung: khôi phục khung mặc định.
Ẩn thiết lập hoặc F11 để mở rộng vùng đồ thị. Esc thoát toàn màn hình.

NHẬP / XUẤT
Nhập dãy mẫu dùng dấu chấm thập phân. CSV một cột hoặc CSV có cột input_x / x[n] đều được hỗ trợ. Hãy nhập đúng fs của dữ liệu.
Xuất CSV lưu tất cả mẫu. Lưu hình lưu đúng đồ thị và khung nhìn đang xem; chọn Xem toàn bộ trước nếu muốn lưu cả dãy tín hiệu.
Khi đổi thông số, nhấn Chạy mô phỏng để cập nhật trước khi xuất. Phát lại không tạo nhiễu mới; chạy mô phỏng mới sẽ tạo lại nhiễu ngẫu nhiên.

PHẠM VI VÀ DIỄN GIẢI
Phiên bản này mô phỏng bộ lọc thông thấp FIR Hamming và IIR Butterworth; chưa mô phỏng bộ lọc thông cao/thông dải hay số học cố định trên phần cứng.
FIR có trễ nhóm (số hệ số − 1) / 2 mẫu. IIR có trễ phụ thuộc tần số. Mọi bộ lọc bắt đầu từ trạng thái 0 nên các mẫu đầu có quá độ.
Số hệ số FIR không phải bậc FIR: bậc bằng số hệ số trừ 1.
Tần số tín hiệu và nhiễu sin phải dưới fs/2. Tần số cắt phải nằm trong (0, fs/2).
Tần số cắt FIR được thiết kế theo mức gần −6 dB; Butterworth theo mức −3 dB. Đây không phải hai đặc tả có cùng độ suy hao tại điểm cắt.
Đáp ứng xung IIR có thể kéo dài vô hạn; màn hình chỉ cho thấy khoảng mẫu đã tính. Không suy ra rằng IIR trở thành FIR khi đường vẽ kết thúc.
Phổ dùng cửa sổ Hann, mốc biên độ 1. Không phải phổ mật độ công suất hay dBFS.
Đường nối giữa các chấm chỉ hỗ trợ quan sát các mẫu rời rạc.

GIỚI HẠN THỰC HÀNH
4–20.000 mẫu; FIR 3–1.001 hệ số lẻ; IIR bậc 1–12.
Khi xem hàng nghìn mẫu, dấu chấm/cọc được ẩn bớt theo chế độ hiển thị để đồ thị dễ đọc. Dữ liệu tính toán và CSV vẫn đầy đủ.
""")

    def close(self):
        self.pause()
        self.root.destroy()


def launch_gui() -> None:
    import tkinter as tk
    import sys
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError, OSError):
            pass
    root = tk.Tk()
    FilterApp(root)
    root.mainloop()


if __name__ == "__main__":
    launch_gui()
