"""Đóng gói trên Windows; người dùng cuối không cần cài Python."""
from __future__ import annotations

import os
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> int:
    if sys.platform != "win32":
        print("Hãy chạy TAO_BAN_WINDOWS.bat trên Windows để tạo bản EXE.")
        return 1
    if sys.version_info < (3, 10) or struct.calcsize("P") != 8:
        print("Cần Python 3.10 trở lên, bản 64-bit. Gợi ý: Python 3.12 64-bit.")
        return 1

    import PyInstaller.__main__

    os.chdir(ROOT)
    # onedir keeps Tcl/Tk, fonts and scientific libraries beside the EXE.
    # Pack the whole directory so the user can extract it and run the app.
    PyInstaller.__main__.run([
        "--noconfirm", "--clean", "--onedir", "--windowed",
        "--name", "FIR_IIR_App",
        "--hidden-import", "matplotlib.backends.backend_tkagg",
        "--distpath", str(ROOT / "dist"),
        "--workpath", str(ROOT / "build"),
        "--specpath", str(ROOT / "build"),
        str(ROOT / "FIR_IIR_App.py"),
    ])

    app_dir = ROOT / "dist" / "FIR_IIR_App"
    if not (app_dir / "FIR_IIR_App.exe").is_file():
        raise RuntimeError("Không tìm thấy EXE sau khi đóng gói. Xem thông báo phía trên.")

    help_file = ROOT / "HUONG_DAN_NGUOI_DUNG.txt"
    (app_dir / help_file.name).write_bytes(help_file.read_bytes())
    archive = ROOT / "dist" / "FIR_IIR_Windows.zip"
    temporary = archive.with_suffix(".tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as package:
        for path in sorted(app_dir.rglob("*")):
            if path.is_file():
                package.write(path, arcname=path.relative_to(app_dir.parent).as_posix())
    temporary.replace(archive)

    print("\nĐã tạo:", archive)
    print("Giải nén ZIP và mở FIR_IIR_App.exe để kiểm tra trước khi đăng Releases.")
    print("Khi chia sẻ, gửi cả ZIP để có đủ EXE và thư mục thư viện đi kèm.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
