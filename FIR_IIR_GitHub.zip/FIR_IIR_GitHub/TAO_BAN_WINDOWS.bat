@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PY_CMD=py -3"
where py >nul 2>nul
if errorlevel 1 (
    where python >nul 2>nul
    if errorlevel 1 goto missing
    set "PY_CMD=python"
)
%PY_CMD% -c "import sys,struct; assert sys.version_info >= (3,10) and struct.calcsize('P') == 8" >nul 2>nul
if errorlevel 1 goto missing
if exist ".venv-build\Scripts\python.exe" goto dependencies
%PY_CMD% -m venv ".venv-build"
if errorlevel 1 goto failed
:dependencies
echo Đang cài công cụ đóng gói. Bước này cần Internet nếu chưa có thư viện.
".venv-build\Scripts\python.exe" -m pip install -r "requirements-build.txt"
if errorlevel 1 goto failed
".venv-build\Scripts\python.exe" "build_windows.py"
if errorlevel 1 goto failed
echo.
echo Thành công. Kiểm tra dist\FIR_IIR_Windows.zip trước khi đăng GitHub Releases.
pause
exit /b 0
:missing
echo Cần Python 3.10 trở lên, 64-bit. Có thể cài Python 3.12 64-bit.
echo Khi cài, bật Python Launcher hoặc Add Python to PATH.
pause
exit /b 1
:failed
echo.
echo Chưa tạo được bản phát hành. Xem lỗi phía trên.
pause
exit /b 1
