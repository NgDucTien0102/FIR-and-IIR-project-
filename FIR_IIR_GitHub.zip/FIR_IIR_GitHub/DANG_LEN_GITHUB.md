# Đưa ứng dụng lên GitHub để mọi người tải về

Repository chứa mã nguồn và hướng dẫn. Mục **Releases** chứa bản ứng dụng dùng sẵn cho người tải.

## 1. Tạo bản Windows

Thực hiện trên máy Windows có Python 64-bit, từ phiên bản 3.10 trở lên; Python 3.12 64-bit là một lựa chọn phù hợp cho gói này.

1. Giải nén gói mã nguồn vào một thư mục.
2. Nhấp đúp **TAO_BAN_WINDOWS.bat**. Cần Internet để tải thư viện lần đầu.
3. Chờ script kết thúc thành công. Bản phát hành nằm ở **dist/FIR_IIR_Windows.zip**.
4. Giải nén ZIP vào một thư mục khác, mở `FIR_IIR_App/FIR_IIR_App.exe` và kiểm tra: chạy mô phỏng, đổi đồ thị, phát/tạm dừng và xuất CSV.

ZIP chứa EXE và thư viện đi kèm. Phát hành cả ZIP; không tách riêng EXE ra khỏi các thư viện của bản này.

Gói bạn nhận hiện là mã nguồn và công cụ đóng gói, **chưa có EXE đã biên dịch**. Tệp `.bat` gọi PyInstaller để tạo EXE trên máy Windows của bạn. Phần đóng gói Windows cần được chạy và kiểm tra tại đó.

## 2. Tạo repository

1. Đăng nhập GitHub, chọn **New repository**.
2. Đặt tên, ví dụ `fir-iir-simulator`.
3. Chọn **Public** nếu muốn mọi người truy cập và tải công khai, rồi tạo repository.
4. Chọn **Add file → Upload files** hoặc đường dẫn **uploading an existing file** ở repository trống.
5. Upload các tệp mã nguồn, README, hướng dẫn, ảnh và script đóng gói trong gói này. Đặt `README.md` và `FIR_IIR_App.py` ngay ở thư mục gốc repository.
6. Nhấn **Commit changes**.

Sau khi chạy script đóng gói, các thư mục `.venv`, `.venv-build`, `build`, `dist` có thể xuất hiện trên máy. Không kéo các thư mục này vào phần upload mã nguồn; tệp ZIP trong `dist` sẽ được đưa vào Releases ở bước tiếp theo.

## 3. Phát hành bản tải về

1. Trong repository, mở **Releases → Draft a new release** (lần đầu có thể hiện **Create a new release**).
2. Tạo tag **v1.0.0** và chọn nhánh chứa mã nguồn đã upload.
3. Đặt tiêu đề, ví dụ **Bộ lọc số FIR/IIR — v1.0.0**.
4. Ghi mô tả ngắn: phiên bản Windows, mô phỏng FIR/IIR thông thấp, đồ thị chạy theo mẫu và không cần cài Python.
5. Kéo **dist/FIR_IIR_Windows.zip** vào ô đính kèm tệp của release. Chờ upload hoàn tất.
6. Nhấn **Publish release**.

Nếu muốn chuẩn bị trước, chọn **Save draft**; mọi người chỉ tải bản này sau khi bạn xuất bản release.

## 4. Gửi link cho người dùng

Link trang bản phát hành mới nhất có dạng sau. Thay hai phần IN HOA bằng tài khoản và tên repository của bạn:

```text
https://github.com/TEN_TAI_KHOAN/TEN_REPOSITORY/releases/latest
```

Link tải thẳng đúng tệp ZIP, sau khi release đã được xuất bản:

```text
https://github.com/TEN_TAI_KHOAN/TEN_REPOSITORY/releases/latest/download/FIR_IIR_Windows.zip
```

Có thể thêm vào đầu README một liên kết Markdown như sau, rồi thay thông tin thật:

```markdown
[Tải ứng dụng cho Windows](https://github.com/TEN_TAI_KHOAN/TEN_REPOSITORY/releases/latest/download/FIR_IIR_Windows.zip)
```

Người dùng thực hiện: **mở link → tải FIR_IIR_Windows.zip → giải nén → mở FIR_IIR_App.exe**.

Hai mục `Source code (zip)` và `Source code (tar.gz)` GitHub tự tạo là mã nguồn. Hãy hướng người dùng phổ thông đến tệp **FIR_IIR_Windows.zip** mà bạn đính kèm.

## 5. Khi có bản mới

Upload mã nguồn đã sửa, chạy lại `TAO_BAN_WINDOWS.bat`, kiểm tra bản tạo ra rồi tạo release với tag mới như `v1.0.1`. Đính kèm ZIP cùng tên và đánh dấu là bản mới nhất. Link `/releases/latest/download/FIR_IIR_Windows.zip` sẽ dẫn đến bản mới nhất.

## Tài liệu chính thức

- [GitHub: quản lý Releases](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository)
- [GitHub: liên kết đến release và tệp tải về](https://docs.github.com/en/repositories/releasing-projects-on-github/linking-to-releases)
- [PyInstaller: cách đóng gói chương trình](https://pyinstaller.org/en/stable/operating-mode.html)
