@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" "FIR_IIR_App.py"
    if errorlevel 1 goto failed
    exit /b 0
)
where py >nul 2>nul
if errorlevel 1 goto try_python
py -3 "FIR_IIR_App.py"
if errorlevel 1 goto failed
exit /b 0
:try_python
where python >nul 2>nul
if errorlevel 1 goto failed
python "FIR_IIR_App.py"
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo Chưa mở được ứng dụng. Hãy chạy CAI_DAT.bat hoặc xem lỗi phía trên.
pause
exit /b 1
