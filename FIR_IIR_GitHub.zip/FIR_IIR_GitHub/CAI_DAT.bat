@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PY_CMD=py -3"
where py >nul 2>nul
if errorlevel 1 (
    where python >nul 2>nul
    if errorlevel 1 goto missing
    set "PY_CMD=python"
)
%PY_CMD% -c "import sys; assert sys.version_info >= (3,10)" >nul 2>nul
if errorlevel 1 goto missing
if exist ".venv\Scripts\python.exe" goto packages
%PY_CMD% -m venv ".venv"
if errorlevel 1 goto failed
:packages
".venv\Scripts\python.exe" -m pip install -r "requirements.txt"
if errorlevel 1 goto failed
echo.
echo Cài đặt hoàn tất. Mở CHAY_UNG_DUNG.bat để sử dụng.
pause
exit /b 0
:missing
echo Cần cài Python 3.10 trở lên và bật Python Launcher hoặc Add Python to PATH.
pause
exit /b 1
:failed
echo Cài đặt chưa hoàn tất. Kiểm tra kết nối Internet và thông báo lỗi phía trên.
pause
exit /b 1
