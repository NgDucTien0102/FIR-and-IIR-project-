# Bộ lọc số FIR / IIR

Ứng dụng desktop tiếng Việt, mỗi lần hiển thị một đồ thị lớn. Phát kết quả theo **chỉ số mẫu n**, có tạm dừng, tua, tiến một mẫu và chỉnh tốc độ phát.

## Chạy trên Windows

Cần Python 3.10 trở lên, có Tkinter (bộ cài Python cho Windows thường kèm sẵn).

1. Giải nén toàn bộ gói vào một thư mục.
2. Lần đầu mở **CAI_DAT.bat** để tạo môi trường `.venv` và cài ba thư viện. Bước này cần Internet.
3. Mở **CHAY_UNG_DUNG.bat** để chạy. Sau khi cài xong, ứng dụng hoạt động ngoại tuyến.

Nếu máy đã chạy được bản cũ, có thể chỉ tải `FIR_IIR_App.py` mới rồi chạy:

```bat
py FIR_IIR_App.py
```

Hoặc cài thủ công:

```bat
py -m pip install numpy scipy matplotlib
py FIR_IIR_App.py
```

Đây là mã nguồn Python, chưa phải tệp EXE đóng gói. Hãy đóng cửa sổ bản cũ trước khi mở bản mới. Tên cửa sổ mới là **Bộ lọc số | FIR & IIR**.

## Thao tác

- **Tín hiệu:** tạo sóng sin, thêm nhiễu sin/ngẫu nhiên hoặc nhập dãy mẫu/CSV/TXT. Các ô thông số nhận cả dấu chấm và dấu phẩy thập phân; riêng dãy mẫu/CSV dùng dấu chấm thập phân.
- **Bộ lọc:** chọn FIR Hamming, IIR Butterworth hoặc cả hai. Thiết lập tần số cắt, số hệ số FIR và bậc IIR.
- **Chạy mô phỏng:** tính kết quả và tự phát khi đang xem tín hiệu. Không xuất hiện cửa sổ đồ thị rời.
- **Đồ thị / Đang xem:** chọn tín hiệu, phổ, đáp ứng biên độ, pha, xung, bậc thang hoặc bảng giá trị.
- **Chọn đường vẽ:** bật/tắt đầu vào, tín hiệu gốc và từng đầu ra. Các đáp ứng bộ lọc chỉ dùng lựa chọn FIR/IIR.
- **Phát/Tạm dừng, Về đầu, +1 mẫu:** điều khiển quan sát. Thanh trượt tua đến một mẫu bất kỳ. **Xem toàn bộ** hiện toàn dãy; bấm Phát để bắt đầu lại.
- **Tốc độ phát:** số mẫu trình diễn mỗi giây, độc lập với tần số lấy mẫu. Có thể không vẽ từng khung hình ở tốc độ cao nhưng dữ liệu mẫu không bị bỏ khỏi tính toán.
- **Cửa sổ quan sát:** chọn số mẫu nhìn thấy trước khi khung hình cuộn. Có chế độ cọc mẫu. Khi có quá nhiều điểm, dùng đường nối để dễ đọc; dữ liệu vẫn đủ.
- **Di chuột khi tạm dừng:** đọc chỉ số mẫu, thời gian tương ứng và biên độ từng đường.
- **Phóng vùng / Kéo đồ thị / Vừa khung:** quan sát chi tiết; thao tác phóng/kéo sẽ tạm dừng phát.
- **Ẩn thiết lập** tăng diện tích đồ thị; **F11** toàn màn hình, **Esc** thoát. **F5** chạy lại mô phỏng.
- **Xuất CSV:** toàn bộ mẫu, có n và t = n/fs, đầu vào, tín hiệu gốc nếu có, đầu ra đã chọn.
- **Lưu hình:** PNG, SVG hoặc PDF của đúng khung nhìn đang xem. Chọn Xem toàn bộ trước nếu cần xuất cả dãy tín hiệu.
- **Thông số và hệ số bộ lọc:** xem b, a, trễ FIR, độ lợi tại tần số tín hiệu/nhiễu và phương trình sai phân.

## Đánh giá phạm vi chức năng

Bản này đủ cho một mô phỏng cơ bản về **so sánh bộ lọc thông thấp FIR và IIR**: nguồn tín hiệu, nhiễu, thiết kế, lọc, phân tích và xuất dữ liệu. Chưa thể kết luận đáp ứng toàn bộ yêu cầu môn học nếu chưa đối chiếu đề cương/chấm điểm của giảng viên.

Chưa có thông cao/thông dải/chắn dải, âm thanh trực tiếp, ADC/DAC, số học fixed-point hoặc triển khai HDL/phần cứng. Đây là phạm vi hiện tại, không phải lỗi giao diện.

## Hiểu đúng kết quả

- Lọc nhân quả một lượt, điều kiện đầu bằng 0; không dùng lọc hai chiều để xóa độ trễ.
- Đồ thị động là phát lại kết quả mô phỏng đã tính. Không phải thu dữ liệu thời gian thực từ phần cứng.
- Trục tín hiệu, đáp ứng xung và bậc thang là **chỉ số mẫu n**, bắt đầu ở 0. Với N mẫu, mẫu cuối ở (N−1)/fs giây.
- Phổ/đáp ứng tần số dùng **Hz** và là đồ thị tĩnh. Phổ được tính từ toàn bộ dãy, không từ cửa sổ phát đang chạy.
- FIR có số hệ số lẻ; bậc FIR = số hệ số − 1. Trễ nhóm = (số hệ số − 1)/2 mẫu. Với 51 hệ số, trễ là 25 mẫu.
- FIR Hamming có điểm cắt gần −6 dB; Butterworth dùng −3 dB. Việc nhập cùng tần số cắt không làm hai bộ lọc có cùng đặc tả suy hao.
- IIR được tính bằng các tầng bậc hai để giảm sai số số học. Bộ lọc vẫn có phản hồi và độ trễ thực của mô hình.
- Đáp ứng xung IIR chỉ được quan sát trong khoảng hữu hạn; kết thúc đường vẽ không có nghĩa là đáp ứng vật lý đã kết thúc.
- Phổ biên độ dùng cửa sổ Hann, mốc 0 dB = biên độ 1. Không phải PSD hoặc dBFS; cửa sổ và chiều dài hữu hạn ảnh hưởng đến đỉnh phổ.
- Mức nhiễu sin là biên độ; mức nhiễu ngẫu nhiên là độ lệch chuẩn. Không hiện tham số khởi tạo ngẫu nhiên trong giao diện. Phát lại giữ nguyên nhiễu; Chạy mô phỏng tạo nhiễu mới.
- Tần số tín hiệu và nhiễu sin phải nhỏ hơn fs/2. Tần số cắt nằm trong (0, fs/2).
- Giới hạn: 4–20.000 mẫu, FIR 3–1.001 hệ số lẻ, IIR bậc 1–12.

## Kiểm tra

Đã kiểm tra phương trình sai phân với kết quả tính tay, tính nhân quả, độ trễ FIR, độ lợi IIR tại điểm cắt, ổn định số ở bậc cao/tần số cắt sát biên, phổ các tín hiệu biết trước, số lượng mẫu và vòng xuất–nhập CSV. Giao diện được kiểm tra bằng Tkinter trên Linux với màn hình ảo. Chưa chạy trực tiếp trên Windows; hai tệp BAT là tiện ích khởi chạy cho Windows.

## Tài liệu thuật toán

- [SciPy firwin](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.firwin.html): thiết kế FIR và quy ước điểm cắt.
- [SciPy butter](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.butter.html): Butterworth và khuyến nghị dạng SOS.
- [SciPy sosfilt](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.sosfilt.html): lọc bằng các tầng bậc hai.
